#include "string.h"
String a;
int main(){
    
}