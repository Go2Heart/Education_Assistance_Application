#ifndef GLOBAL_H
#define GLOBAL_H

extern class Students studentGroup;
extern class Activities ActivityGroup;
extern class Lessons lessonGroup;
extern class Socket sock;

#endif